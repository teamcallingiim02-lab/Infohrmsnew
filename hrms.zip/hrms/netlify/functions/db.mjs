import { getStore } from "@netlify/blobs";

export default async (req) => {
  const store = getStore("hrms");
  const url = new URL(req.url);

  if (url.pathname === "/api/db") {
    if (req.method === "GET") {
      const v = await store.get("db");
      return new Response(v || "", { headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
    }
    if (req.method === "POST") {
      const body = await req.text();
      try { JSON.parse(body); } catch { return new Response("bad", { status: 400 }); }
      await store.set("db", body);
      return new Response("ok");
    }
  }

  if (url.pathname === "/api/file") {
    const key = "f_" + (url.searchParams.get("key") || "").replace(/[^\w.\-]/g, "_");
    if (req.method === "POST") {
      const buf = await req.arrayBuffer();
      await store.set(key, buf, { metadata: { type: req.headers.get("content-type") || "application/octet-stream" } });
      return new Response("ok");
    }
    if (req.method === "GET") {
      const r = await store.getWithMetadata(key, { type: "arrayBuffer" });
      if (!r) return new Response("Not found", { status: 404 });
      return new Response(r.data, { headers: { "Content-Type": (r.metadata && r.metadata.type) || "application/octet-stream", "Cache-Control": "no-store" } });
    }
  }
  return new Response("Not found", { status: 404 });
};

export const config = { path: ["/api/db", "/api/file"] };
