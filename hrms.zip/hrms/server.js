// HRMS local server (Node.js, no extra packages). Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data.json');
const UP = path.join(__dirname, 'uploads');
if (!fs.existsSync(UP)) fs.mkdirSync(UP);
const safe = k => String(k || '').replace(/[^\w.\-]/g, '_');

http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x'), p = u.pathname;
  if (p === '/api/db') {
    if (req.method === 'GET') {
      res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
      return res.end(fs.existsSync(DATA) ? fs.readFileSync(DATA) : '');
    }
    if (req.method === 'POST') {
      const c = []; req.on('data', d => c.push(d));
      return req.on('end', () => {
        const b = Buffer.concat(c).toString();
        try { JSON.parse(b); fs.writeFileSync(DATA, b); res.writeHead(200); res.end('ok'); }
        catch (e) { res.writeHead(400); res.end('bad'); }
      });
    }
  }
  if (p === '/api/file') {
    const f = path.join(UP, safe(u.searchParams.get('key')));
    if (req.method === 'POST') {
      const c = []; req.on('data', d => c.push(d));
      return req.on('end', () => {
        fs.writeFileSync(f, Buffer.concat(c));
        fs.writeFileSync(f + '.type', req.headers['content-type'] || 'application/octet-stream');
        res.writeHead(200); res.end('ok');
      });
    }
    if (req.method === 'GET') {
      if (!fs.existsSync(f)) { res.writeHead(404); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': fs.readFileSync(f + '.type', 'utf8'), 'Cache-Control': 'no-store' });
      return res.end(fs.readFileSync(f));
    }
  }
  if (p === '/' || p === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
  }
  res.writeHead(404); res.end('Not found');
}).listen(PORT, '0.0.0.0', () => {
  console.log('HRMS running:\n  This PC: http://localhost:' + PORT);
  Object.values(os.networkInterfaces()).flat().filter(i => i.family === 'IPv4' && !i.internal)
    .forEach(i => console.log('  Other systems on same Wi-Fi/LAN: http://' + i.address + ':' + PORT));
});
